# 13. Genera una función la cual, para un conjunto de caracteres, devuelva una lista de tuplas con cada letra en mayúsculas y minúsculas. Las letras no pueden estar repetidas.Usa la función map()

def convertir(letra):                         # Creamos una función para convertir una tupla de letras de minucsulas a mayusculas y viceversa.
    return letra.upper(), letra.lower()

def mayusc_minusc(caracteres):                # Creamos otra función para un conjunto de caracteres
    unicos = []                               # Creamos el variable unicos con lista vacia
    for c in caracteres:                      # Recorremos caracter a caracter con el bucle for el conjuto de caracteres
        if c.lower() not in unicos:           # Si el caracter convertido a minusculas no esta en la lista, se añade. Si no, no.
            unicos.append(c.lower())          # Al final del bucle se insertan en la lista unicos los caracteres únicos y en minusculas
    return list(map(convertir, unicos))       # Mediante map se aplica la funcion convertir a cada elemento de unicos y se converte a lista de tuplas. 

# Ejemplo: "Alameda"

letras = "Alameda"
print(mayusc_minusc(letras))

# Output: [('A', 'a'), ('L', 'l'), ('M', 'm'), ('E', 'e'), ('D', 'd')]