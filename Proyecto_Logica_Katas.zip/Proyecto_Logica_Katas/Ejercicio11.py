# 11. Escribe un programa que pida al usuario que introduzca su edad. Si el usuario ingresa un valor no numérico o un valor fuera del rango esperado (por ejemplo, menor que 0 o mayor que 120), maneja las excepciones adecuadamente.

try:
    edad = float(input("Ingrese su edad: "))
    if edad < 0 or edad > 120:
        raise ValueError("Ingrese una edad válida (entre 0-120)")
except ValueError:
    print("Ingrese una edad válida (entre 0-120)")
else:
    print("Su edad es:", round(edad, 2))

# Ejemplo: Input 25
# Output: 25.0

# Ejemplo: Input 127
# Output:  Ingrese una edad válida (entre 0-120)