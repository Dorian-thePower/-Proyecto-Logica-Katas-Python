# 23. Concatena una lista de palabras.Usa la función reduce().

from functools import reduce

def concatenar(a, b):
    return a + " " + b

def lista_reducida(palabras):
    return reduce(concatenar, palabras)
# Ejemplo

palabras = ["Python", "JAVAscript", "CSS", "Robin Hood"]
print(lista_reducida(palabras))

# Output: "Python JAVAscript CSS Robin Hood"