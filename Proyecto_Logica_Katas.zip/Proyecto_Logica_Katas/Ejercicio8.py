# Escribe un programa que pida al usuario dos números e intente dividirlos. 
# Si el usuario ingresa un valor no numérico o intenta dividir por cero, maneja esas excepciones de manera adecuada. 
# Asegúrate de mostrar un mensaje indicando si la división fue exitosa o no.

try:
    a = float(input("Ingrese el primer número: "))
    b = float(input("Ingrese el segundo número: "))
    resultado = a / b
except ValueError:
    print("Debe ingresar un número válido")
except ZeroDivisionError:
    print("No se puede dividir entre cero")
else:
    print("El resultado de la división es:", round(resultado, 2))

# Ejemplo: input 5 / 7
# Output: El resultado de la división es: 0.71

# Ejemplo: input A
# Output: Debe ingresar un número válido

# Ejemplo: input 3 / 0
# Output: No se puede dividir entre cero