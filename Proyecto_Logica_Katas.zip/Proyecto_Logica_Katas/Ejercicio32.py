# 32. Crea una función que tome un nombre completo y una lista de empleados, 
# busque el nombre completo en la lista y devuelve el puesto del empleado si está en la lista, de lo contrario, 
# devuelve un mensaje indicando que la persona no trabaja aquí.


def buscar_empleado(nombre_empleado, lista_empleados):                           # Definimos una función con dos parámetros: el nombre del empleado a buscar y la lista de empleados.
    for empleado in lista_empleados:                                             # Se recorre cada empleado en la lista de empleados.
        if empleado["nombre"] == nombre_empleado:                                # Si el nombre del empleado coincide con el nombre que estamos buscando,
           return empleado["posicion"]                                           # se devuelve el puesto del empleado.
        
    return f"{nombre_empleado} no trabaja aquí"                                  # Si el bucle termina sin encontrar el empleado, se devuelve un mensaje indicando que la persona no trabaja aquí.
           
empleados = [{"nombre": "Marta Gomez", "posicion": "Analista"},                  # Creamos una lista de empleados, donde cada empleado es un diccionario con su nombre y posición.
             {"nombre": "Roberto Cuco", "posicion": "Comercial"},
             {"nombre": "Nuria Beltran", "posicion": "Contable"}
]

# Ejemplo:

print(buscar_empleado("Roberto Cuco", empleados))                              # Buscamos el nombre del empleado en la lista de empleados y mostramos su posición si se encuentra, o un mensaje si no se encuentra.

# Output: Comercial