# 15. Crea una función lambda que sume 3 a cada número de una lista dada

# 1.- Definimos la función lambda que recorre los elementos números en una lista de numeros y les suma 3 a cada uno. 
funcion_lambda_sum3 = lambda lista_numeros: [elemento + 3 for elemento in lista_numeros]

# 2.- Creamos una lista de números de prueba
lista_num_prueba = [34, 39, 12, 15]

# 3.- Llamamos a nuestra función lambda con la lista de números de prueba y almacenamos el resultado
lista_numeros_sum3 = funcion_lambda_sum3(lista_num_prueba)

print(lista_numeros_sum3)

# Output: [37, 42, 15, 18]