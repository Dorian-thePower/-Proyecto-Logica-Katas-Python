# 22. Dada una lista numérica, obtén el producto total de los valores de dicha lista.Usa la función reduce() 

from functools import reduce

def sumar(a, b):
    return a + b

def total_numero(producto):
    return reduce(sumar, producto)

# Ejemplo:
productos = [1, 2, 3, 5, 6, 7, 9]
print(total_numero(productos))

# Output: 33