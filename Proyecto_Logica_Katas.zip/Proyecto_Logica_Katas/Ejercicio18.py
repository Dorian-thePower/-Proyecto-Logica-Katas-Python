# 18. Escribe un programa en Python que cree una lista de diccionarios que contenga información de estudiantes (nombre, edad, calificación) y use la función filter para extraer a los estudiantes con una calificación mayor o igual a 90. 
# Usa la función filter()

estudiantes = [
      {"Nombre": "Ana", "edad": 19, "calificacion": 89},           # definimos un variable con lista de diccionarios nombre, edad, calificación.
      {"Nombre": "Pedro", "edad": 21, "calificacion": 91},
      {"Nombre": "Lola", "edad": 23, "calificacion": 95},
      {"Nombre": "Luis", "edad": 22, "calificacion": 88}
]

def calificacion_alta(estudiante):                                 # definimos la función para destacar los estudiantes con calificacion igual o mayor de 90
    return estudiante["calificacion"] >= 90

estudiantes_destacados = list(filter(calificacion_alta, estudiantes))  # filtramos en la función los estudinantes que cumplen el requisito de retorno
print(estudiantes_destacados)

# Output: [{'Nombre': 'Pedro', 'edad': 21, 'calificacion': 91}, {'Nombre': 'Lola', 'edad': 23, 'calificacion': 95}]