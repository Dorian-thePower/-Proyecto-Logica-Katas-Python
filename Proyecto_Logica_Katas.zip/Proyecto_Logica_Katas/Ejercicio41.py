# 41. En este ejercicio, se te pedirá que escribas un programa en Python que utilice condicionales para determinar el monto final de una compra en una tienda en línea, después de aplicar un descuento. El programa debe hacer lo siguiente:
# 1. Solicita al usuario que ingrese el precio original de un artículo.
# 2. Pregunta al usuario si tiene un cupón de descuento (respuesta sí o no).
# 3. Si el usuario responde que sí, solicita que ingrese el valor del cupón de descuento.
# 4. Aplica el descuento al precio original del artículo, siempre y cuando el valor del cupón sea válido (es decir, mayor #a cero). Por ejemplo, descuento de 15€. 
# 5. Muestra el precio final de la compra, teniendo en cuenta el descuento aplicado o sin él. 
# 6. Recuerda utilizar estructuras de control de flujo como if, elif y else para llevar a cabo estas acciones en tu programa de Python


precio = float(input("Introduce el precio original del artículo: "))                   # 1. Solicitamos al usuario que ingrese el precio original de un artículo y lo convertimos a un número flotante para poder realizar cálculos con él.

tiene_cupon = input("¿Tienes un cupón de descuento? (sí/no): ").lower()                # 2. Preguntar si tiene cupón

descuento = 0                                                                          # 3. Si el usuario responde que sí, solicitamos que ingrese el valor del cupón de descuento y lo convertimos a un número float para poder realizar cálculos con él. Si el usuario responde que no, no se aplicará ningún descuento. Si la respuesta no es válida, se mostrará un mensaje indicando que no se aplicará ningún descuento.

if tiene_cupon == "sí" or tiene_cupon == "si":                                         # Se verifica si la respuesta del usuario es "sí" o "si" (en minúsculas para evitar problemas de mayúsculas).
    valor_cupon = float(input("Introduce el valor del cupón: "))                       # Si el usuario tiene un cupón, se solicita que ingrese el valor del cupón y se convierte a un número float.
    
    if valor_cupon > 0:                                                                # Se verifica si el valor del cupón es mayor que cero para determinar si es válido.
        descuento = valor_cupon
    else:                                                                              # Si el valor del cupón no es válido (<=0), se muestra un mensaje indicando que el cupón no es válido y no se aplicará ningún descuento.
        print("Cupón no válido. No se aplicará descuento.")
elif tiene_cupon == "no":                                                              # Si el usuario responde que no tiene un cupón, se muestra un mensaje indicando que no se aplicará ningún descuento.
    print("No se aplicará ningún descuento.")
else:                                                                                  # Si la respuesta del usuario no es ni "sí" ni "no", se muestra un mensaje indicando que la respuesta no es válida y no se aplicará ningún descuento.
    print("Respuesta no válida. No se aplicará descuento.")


precio_final = precio - descuento                                                      # 4. Se calcula el precio final de la compra restando el descuento al precio original del artículo.

if precio_final < 0:                                                                   # Se verifica si el precio final es menor que cero, lo cual no tendría sentido en una compra. Si es así, el precio final se convierte en 0 para no mostrar un importe negativo. 
   precio_final = 0

print("El precio final de la compra es:", precio_final, "€")                           # 5. Se muestra el precio final de la compra, teniendo en cuenta el descuento aplicado o sin él, dependiendo de si el usuario tenía un cupón válido o no. El precio final se muestra en euros (€).


# Ejemplo:
# El precio original del artículo es 100€
# El cupon de descuento es 15€.
# El precio final de la compra es 85€.

# Output:
# Introduce el precio original del artículo: 100
# ¿Tienes un cupón de descuento? (sí/no): sí
# Introduce el valor del cupón: 15
# El precio final de la compra es: 85.0 €