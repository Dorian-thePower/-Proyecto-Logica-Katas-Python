# 4. Genera una función que calcule la diferencia entre los valores de dos listas. Usa la función map()

def restar(x,y):
    return x - y

def diferencia_listas(lista1, lista2):
    return list(map(restar, lista1, lista2))

# Ejemplo

lista1 = [32, 76, 25]
lista2 = [13, 7, 10]

print(diferencia_listas(lista1, lista2))

# Output: [19, 69, 15]