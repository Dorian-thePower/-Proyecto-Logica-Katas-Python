# 3. Escribe una función que tome una lista de palabras y una palabra objetivo como parámetros. La función debe devolver una lista con todas las palabras de la lista original que contengan la palabra objetivo.


def lista_original(lista_palabras, palabra_objetivo):         # Fijamos los parametros, lista_palabras y palabra_objetivo
    lista_nueva = []                                          # Creamos un variable lista_nueva como lista vacia
    for palabra in lista_palabras:                            # Se recorre en la lista de palabras las palabras que cumplan la condición de palabra_objetivo y la añadimos a la lista_nueva vacia.
        if palabra_objetivo.lower() in palabra.lower():       # Usamos la función lower() para no discriminar entre mayúsculas y minúsculas.
           lista_nueva.append(palabra)
    return lista_nueva

# Ejemplo:

palabras = ["Dispuesto", "DISPONIBLE", "Indispensable", "DISturbio", "Destacado"]
palabra_objetivo = "Dis"

print(lista_original(palabras, palabra_objetivo))

# Output: ['Dispuesto', 'DISPONIBLE', 'Indispensable', 'DISturbio']