# 28. Crea una función que busque y devuelva el primer elemento duplicado en una lista dada.

def primer_duplicado(lista):                   # Definimos una función llamada primer_duplicado que recibe una lista como argumento.
    vistos = set()                             # Creamos un conjunto vacío llamado vistos para almacenar los elementos de una lista.
    for elemento in lista:                     # Se recorre cada elemento en la lista utilizando un bucle for.
        if elemento in vistos:                 # Verificamos si el elemento actual ya ha sido visto anteriormente utilizando la condición if elemento in vistos. 
            return elemento                    # Si el elemento ya ha sido visto, se devuelve ese elemento como el primer duplicado encontrado.
        vistos.add(elemento)                   # Si el elemento no ha sido visto antes, se agrega al set de vistos utilizando el método add(). 
    return None                                # Si no hay duplicados

# Ejemplo:
numeros = [3, 4, 5, 6, 3, 7, 8]
print(primer_duplicado(numeros))

# Output: 3