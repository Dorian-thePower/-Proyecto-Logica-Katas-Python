# 36. Crea la clase UsuarioBanco ,representa a un usuario de un banco con su nombre, saldo y si tiene o no cuenta corriente. Proporciona métodos para realizar operaciones como retirar dinero, transferir dinero desde otro usuario y 
# agregar dinero al saldo.
# Código a seguir:
# 1. Inicializar un usuario con su nombre, saldo y si tiene o no cuenta corriente mediante True o False .
# 2. Implementar el método retirar_dinero para retirar dinero del saldo del usuario. Lanzará un error en caso de no poder hacerse.
# 3. Implementar el método transferir_dinero para realizar una transferencia desde otro usuario al usuario actual. Lanzará un error en caso de no poder hacerse.
# 4. Implementar el método agregar_dinero para agregar dinero al saldo del usuario

# Caso de uso:
# 1. Crear dos usuarios: "Alicia" con saldo inicial de 100 y "Bob" con saldo inicial de 50, ambos con cuenta corriente.
# 2. Agregar 20 unidades de saldo de "Bob".
# 3. Hacer una transferencia de 80 unidades desde "Bob" a "Alicia".
# 4. Retirar 50 unidades de saldo a "Alicia"

class UsuarioBanco:                                                           # Creamos la clase UsuarioBanco
    def __init__(self, nombre, saldo, cuenta_corriente):                      # 1. Inicializamos el usuario con su nombre, saldo y si tiene o no cuenta corriente mediante Treu o False .
        self.nombre = nombre                                                  # metodo constructor que recibe el nombre, saldo y cuenta_corriente como parámetros y los asigna a los atributos de la clase.
        self.saldo = saldo
        self.cuenta_corriente = cuenta_corriente   

    def retirar_dinero(self, cantidad):                                       # 2. Implementamos el método retirar_dinero para retirar dinero del saldo del usuario. Lanzará un error en caso de no poder hacerse.
        if cantidad <= 0:                                                     # Si la cantidad a retirar es menor o igual a cero, se lanza un error indicando que la cantidad debe ser mayor que cero.
            raise ValueError("La cantidad debe ser mayor que cero")

        if cantidad > self.saldo:                                             # Si la cantidad a retirar es mayor que el saldo disponible, se lanza un error indicando que el saldo es insuficiente para retirar dinero.
            raise ValueError("Saldo insuficiente para retirar dinero")
        
        self.saldo -= cantidad                                                # se resta la cantidad del saldo del usuario, retirando el dinero solicitado.

    def transferir_dinero(self, otro_usuario, cantidad):                     # 3. Implementamos el método transferir_dinero para realizar una transferencia desde otro usuario al usuario actual. Lanzará un error en caso de no poder hacerse.
        if cantidad <= 0:                                                    # Si la cantidad a transferir es menor o igual a cero, se lanza un error indicando que la cantidad debe ser mayor que cero.
            raise ValueError("La cantidad debe ser mayor que cero")

        if cantidad > otro_usuario.saldo:                                    # Si la cantidad a transferir es mayor que el saldo del otro usuario, se lanza un error indicando que el otro usuario no tiene suficiente saldo para transferir.
            raise ValueError(f"{otro_usuario.nombre} no tiene suficiente saldo para transferir")

        otro_usuario.saldo -= cantidad                                       # El otro usuario envía dinero al usuario actual, restando la cantidad del saldo del otro usuario y sumándola al saldo del usuario actual.
        self.saldo += cantidad                                               # El usuario actual recibe el dinero, sumando la cantidad al saldo del usuario actual.

    def agregar_dinero(self, cantidad):                                      # 4. Implementamos el método agregar_dinero para agregar dinero al saldo del usuario.
        if cantidad <= 0:                                                    # Si la cantidad a agregar es menor o igual a cero, se lanza un error indicando que la cantidad debe ser mayor que cero.
            raise ValueError("La cantidad debe ser mayor que cero")

        self.saldo += cantidad                                               # Se agrega la cantidad al saldo del usuario.

    
    def info_usuario(self):                                                  # Método para mostrar la información del usuario en formato de diccionario.
        return {
            "nombre": self.nombre,
            "saldo": self.saldo,
            "cuenta_corriente": self.cuenta_corriente
        }


# Ejemplo:

alicia = UsuarioBanco("Alicia", 100, True)                                   # 1. Crear dos usuarios
bob = UsuarioBanco("Bob", 50, True)

bob.agregar_dinero(40)                                                       # 2. Agregar 20 unidades al saldo de Bob

alicia.transferir_dinero(bob, 80)                                            # 3. Hacer una transferencia de 80 unidades desde Bob a Alicia

alicia.retirar_dinero(50)                                                    # 4. Retirar 50 unidades de saldo a Alicia


print(alicia.info_usuario())
print(bob.info_usuario())

# Output:
# {'nombre': 'Alicia', 'saldo': 130, 'cuenta_corriente': True}
# {'nombre': 'Bob', 'saldo': 10, 'cuenta_corriente': True}