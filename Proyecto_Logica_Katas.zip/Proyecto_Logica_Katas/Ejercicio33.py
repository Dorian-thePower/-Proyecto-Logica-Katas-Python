# 33. Crea una función lambda que sume elementos correspondientes de dos listas dadas.

sumar_listas = lambda lista1, lista2: list(map(lambda x, y: x + y, lista1, lista2))

a = [1, 3, 4, 5, 7]
b = [2, 5, 5, 7, 5]

print(sumar_listas(a, b))

# Output: [3, 8, 9, 12, 12]