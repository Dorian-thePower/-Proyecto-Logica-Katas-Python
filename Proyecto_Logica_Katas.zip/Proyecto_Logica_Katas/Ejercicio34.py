# 34. Crea la clase Arbol , define un árbol genérico con un tronco y ramas como atributos. 
# Los métodos disponibles son: crecer_tronco , nueva_rama , crecer_ramas , quitar_rama e info_arbol . 
# El objetivo es implementar estos métodos para manipular la estructura del árbol.
#  Código a seguir:
# 1. Inicializar un árbol con un tronco de longitud 1 y una lista vacía de ramas.
# 2. Implementar el método crecer_tronco para aumentar la longitud del tronco en una unidad.
# 3. Implementar el método nueva_rama para agregar una nueva rama de longitud 1 a la lista de ramas.
# 4. Implementar el método crecer_ramas para aumentar en una unidad la longitud de todas las ramas existentes.
# 5. Implementar el método quitar_rama para eliminar una rama en una posición específica.
# 6. Implementar el método info_arbol para devolver información sobre la longitud del tronco, 
# el número de ramas y las longitudes de las  mismas.

# Caso de uso: 
# 1. Crear un árbol.
# 2. Hacer crecer el tronco del árbol una unidad.
# 3. Añadir una nueva rama al árbol.
# 4. Hacer crecer todas las ramas del árbol una unidad.
# 5. Añadir dos nuevas ramas al árbol.
# 6. Retirar la rama situada en la posición 2.
# 7. Obtener información sobre el árbol.


                                                
class Arbol:                                                       # Creamos la clase arbol
    def __init__(self):                                            # 1. Inicializamos el arbol con un tronco de longitud 1 y una lista vacía de ramas
        self.tronco = 1                                            #    definimos la longitud del tronco inicializada en 1
        self.ramas = []                                            #    creamos una lista vacía de ramas

    def crecer_tronco(self):                                       # 2. Definimos el método crecer_tronco para aumentar la longitud del tronco en una unidad
        self.tronco += 1                                           #   metodo para agregar una nueva rama de longitud 1 a la lista de ramas
    
    def nueva_rama(self):                                          # 3. Definimos el método nueva_rama para agregar una nueva rama de longitud 1 a la lista de ramas
        self.ramas.append(1)                                       #    metodo para aumentar en una unidad la longitud de todas las ramas existentes

    def crecer_ramas(self):                                        # 4. Definimos el método crecer_ramas para aumentar en una unidad la longitud de todas las ramas existentes
        self.ramas = [r + 1 for r in self.ramas]                   #    metodo utilizado con bucle for en list comprehension. 

    def quitar_rama(self, posicion):                               # 5. Definimos el método quitar_rama para eliminar una rama en una posición específica
        if 0 <= posicion < len(self.ramas):                        #    verificamos que la posición sea válida antes de eliminar la rama
            self.ramas.pop(posicion)                               #    eliminamos la rama en la posición especificada
        else:                                                      #    si la posición es inválida, mostramos un mensaje de error
            print("Posición inválida")                        

    def info_arbol(self):                                          # 6. Definimos el método info_arbol para devolver información sobre la longitud del tronco, el número de ramas y las longitudes de las mismas
        return {                                                   #    devolvemos un diccionario con la información del árbol
            "longitud_tronco": self.tronco,
            "numero_ramas": len(self.ramas),
            "longitudes_ramas": self.ramas
        }

# Ejemplo:


arbol = Arbol()                                                    # 1. Crear un árbol

arbol.crecer_tronco()                                              # 2. Hacer crecer el tronco una unidad

arbol.nueva_rama()                                                 # 3. Añadir una nueva rama

arbol.crecer_ramas()                                               # 4. Hacer crecer todas las ramas una unidad

# 5. Añadir dos nuevas ramas
arbol.nueva_rama()                                                 # 5. Añadir dos nuevas ramas
arbol.nueva_rama()

arbol.quitar_rama(2)                                               # 6. Retirar la rama situada en la posición 2

print(arbol.info_arbol())                                          # 7. Obtener información del árbol

# Output: {'longitud_tronco': 2, 'numero_ramas': 2, 'longitudes_ramas': [2, 1]}

