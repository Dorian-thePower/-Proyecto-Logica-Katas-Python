# 40. Escribe una función que tome dos parámetros: figura (una cadena que puede ser "rectángulo", "circulo" o "triangulo") y datos (una tupla con los datos necesarios para calcular el área de la figura).
def calcular_area(figura, datos):
    figura = figura.lower()

    if figura == "rectángulo":                                  # Creamos la condición para verificar si la figura es un rectángulo. 
        base, altura = datos                                    # Creamos las variables base y altura a partir de los datos proporcionados.
        return base * altura                                    # se devuelve el área de un rectángulo, multiplicando la base por la altura.

    elif figura == "circulo":                                   # si la figura es un círculo, se calcula el área utilizando la fórmula que calcula el area del circulo.                           
        (radio,) = datos
        return 3.14159 * (radio ** 2)

    elif figura == "triangulo":                                # si la figura es un triángulo, se calcula el área utilizando la fórmula que calcula el area del triangulo.
        base, altura = datos
        return (base * altura) / 2

    else:                                                      # Si la figura no es reconocida, se devuelve un mensaje indicando que la figura no es válida.
        return "Figura no reconocida"


print(calcular_area("rectángulo", (5, 8)))     # Output: 40
print(calcular_area("circulo", (3,)))          # Output: 28.27431
print(calcular_area("triangulo", (7, 5)))      # Output: 17.5