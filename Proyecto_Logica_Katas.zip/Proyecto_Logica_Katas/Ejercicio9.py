# 9. Escribe una función que tome una lista de nombres de mascotas como parámetro y devuelva una nueva lista excluyendo ciertas mascotas prohibidas en España. 
# La lista de mascotas a excluir es ["Mapache", "Tigre", "Serpiente Pitón", "Cocodrilo", "Oso"]. 
# Usa la función filter()

def mascota_permitida(mascota):
    prohibidas = ["Mapache", "Tigre", "Serpiente Pitón", "Cocodrilo", "Oso"]
    return mascota not in prohibidas

def filtrar_mascotas(lista_mascotas):
    return list(filter(mascota_permitida, lista_mascotas))

# Ejemplo:

mascotas = ["Perro", "Gato", "Mapache", "Tortuga", "Oso", "Canario"]

resultado = filtrar_mascotas(mascotas)

print(resultado)

# Output: ['Perro', 'Gato', 'Tortuga', 'Canario']
