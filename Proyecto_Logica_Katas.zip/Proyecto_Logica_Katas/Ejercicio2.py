# 2. Dada una lista de números, obtén una nueva lista con el doble de cada valor. Usa la función map()

def duplicar(x):
    return x * 2

# Ejemplo:

numeros = [1, 2, 3, 4, 5]

numeros_dobles = list(map(duplicar, numeros))

print(numeros_dobles)

# Output: [2, 4, 6, 8, 10]

