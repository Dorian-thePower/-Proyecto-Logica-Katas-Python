# 12. Genera una función que al recibir una frase devuelva una lista con la longitud de cada palabra. Usa la función map()

def longitud_palabras(frase):
    palabras = frase.split()

    return list(map(len, palabras))

# Ejemplo:

frase = "Hoy es un buen dia para entrenar"
print(longitud_palabras(frase))

# Output: [3, 2, 2, 4, 3, 4, 8]