# 21. Crea una función que calcule el cubo de un número dado mediante una función lambda

elevar_cubo = lambda n: n ** 3

# Ejemplo
print(elevar_cubo(3))

# Output: 27