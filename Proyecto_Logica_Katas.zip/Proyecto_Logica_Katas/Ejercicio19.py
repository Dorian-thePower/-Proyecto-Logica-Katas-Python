# 19 Crea una función lambda que filtre los números impares de una lista dada

def filtrar_impares(lista):
    return list(filter(lambda x: x % 2 != 0, lista))

# Ejemplo:

lista = [1, 2, 4, 5, 6, 7, 5]
print(filtrar_impares(lista))

# Output: [1, 5, 7, 5]