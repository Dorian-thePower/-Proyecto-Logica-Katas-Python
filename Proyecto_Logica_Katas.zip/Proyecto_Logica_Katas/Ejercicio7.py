# 7. Genera una función que convierta una lista de tuplas a una lista de strings. Usa la función map()

def tupla_a_string(tupla):
    return tupla

def tuplas_a_strings(lista_tuplas):
    return list(map(tupla_a_string, lista_tuplas))

# Ejemplo:

lista = [('1'), ("Star Wars"), ('33'), ("Python")]

resultado = tuplas_a_strings(lista)

print(resultado)

# Output: ['1', 'Star Wars', '33', 'Python']