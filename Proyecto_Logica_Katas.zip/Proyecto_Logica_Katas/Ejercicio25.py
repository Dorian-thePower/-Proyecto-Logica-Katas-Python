# 25. Crea una función que cuente el número de caracteres en una cadena de texto dada.


def contar_caracteres(texto):
    return len(texto)

# Ejemplo:
texto = "Hoy es un día bonito"
print(contar_caracteres(texto))

# Output: 20