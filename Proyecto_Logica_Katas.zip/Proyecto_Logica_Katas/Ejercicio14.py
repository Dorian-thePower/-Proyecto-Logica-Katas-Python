# 14. Crea una función que retorne las palabras de una lista de palabras que contengan una letra en especifico. Usa la función filter()

def lista_palabras(palabra):
    letra = 'y'
    return letra.lower() in palabra.lower()

def filtrar_palabras(lista):
    return list(filter(lista_palabras, lista))

# Ejemplo:

lista =  "Maracuya", "PAPAYA", "Banana", "Coco"
print(filtrar_palabras(lista))

# Output: ['Maracuya', 'PAPAYA']