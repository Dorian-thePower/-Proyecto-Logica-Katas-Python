# 38. Genera un programa que nos diga si es de noche, de día o tarde según la hora proporcionada por el usuario.

hora = int(input("Ingrese la hora (0-24): "))

if hora < 0 or hora > 24:
    print("Hora no válida")
elif hora >= 0 and hora <= 12:
    print("Es de día")
elif hora >= 12 and hora <= 18:
    print("Es tarde")
else:
    print("Es de noche")

# Ejemplo:

# Input: 6 
# Output: Es de día
# Input: 18 
# Output: Es tarde
# Input: 20 
# Output: Es de noche
# Input: 25
# Output: Hora no válida