# 26. Crea una función lambda que calcule el resto de la división entre dos números dados.

funcion_lambda = lambda x, y: x % y

# Ejemplo:

print(funcion_lambda(10, 3))  

# Output: 1