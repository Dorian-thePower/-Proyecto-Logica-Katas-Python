# 39. Escribe un programa que determine qué calificación en texto tiene un alumno en base a su calificación numérica. 
# Las reglas de calificación son:
# - 0  - 69 insuficiente
# - 70 - 79 bien
# - 80 - 89 muy bien
# - 90 - 100 excelente 


def calificacion_texto(nota):
    if nota < 0 or nota > 100:
        return "Calificación no válida"
    elif nota <= 69:
        return "insuficiente"
    elif nota <= 79:
        return "bien"
    elif nota <= 89:
        return "muy bien"
    else:
        return "excelente"

# Ejemplo:

nota = 67
resultado = print(calificacion_texto(nota))

# Output: insuficiente