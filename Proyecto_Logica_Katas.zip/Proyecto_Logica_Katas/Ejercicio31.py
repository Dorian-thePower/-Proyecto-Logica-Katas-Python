# 31. Crea una función que solicite al usuario ingresar una lista de nombres y luego solicite un nombre para buscar en esa lista. 
# Si el nombre está en la lista, se imprime un mensaje indicando que fue encontrado, de lo contrario, se lanza una excepción.


def buscar_nombre():                                                         # Define la función buscar_nombre que no recibe parámetros
    lista_nombres = input("Ingrese una lista de nombres: ").split(",")       # Separa los nombres por comas y crea una lista
    nombre_buscar = input("Ingrese un nombre para buscar en la lista: ")     # Solicita el nombre a buscar
    
    if nombre_buscar.lower() in [n.lower() for n in lista_nombres]:          # Compara el nombre a buscar con los nombres de la lista, ignorando mayúsculas/minúsculas
        return nombre_buscar                                                 # Si se encuentra, devuelve el nombre encontrado
    else:                                                                    # Si no se encuentra, lanza una excepción con un mensaje de error
        raise ValueError(f"{nombre_buscar} no se encuentra en la lista")     # El mensaje de error incluye el nombre que se intentó buscar


try:                                                                         # Intenta ejecutar la función buscar_nombre y captura el resultado
    nombre = buscar_nombre()                                                 # Si se encuentra el nombre, se almacena en la variable 'nombre'
    print(f"El nombre encontrado es {nombre}")                               # Imprime un mensaje indicando el nombre encontrado
except ValueError as e:                                                      # Si se lanza una excepción de tipo ValueError, captura el error en la variable 'e'
    print(e)                                                                 # Imprime el mensaje de error capturado, que indica que el nombre no se encuentra en la lista

# Ejemplo:
# Ingrese una lista de nombres: Ana, Pedro, Marta, Luis
# Ingrese un nombre para buscar en la lista: Pedro

# Output: El nombre encontrado es Pedro