# 29. Crea una función que convierta una variable en una cadena de texto 
# y enmascare todos los caracteres con el carácter '#', excepto los últimos cuatro.

def enmascarar(variable):                                                     # Definimos la función enmascarar que toma una variable como argumento.
    variable_str = str(variable)                                              # Convertimos la variable a una cadena de texto y la almacenamos en la variable variable_str.
    if len(variable_str) <= 4:                                                # Verificamos si la longitud de variable_str es menor o igual a 4.
       return variable_str                                                    # Si la longitud es menor o igual a 4, devolvemos variable_str sin enmascarar.
    
    else:                                                                     # Si la longitud es mayor a 4, enmascaramos todos los caracteres excepto los últimos cuatro.
       return '#' * (len(variable_str) - 4) + variable_str[-4:]               # Devolvemos una cadena de caracteres '#' repetida y concatenada con los últimos cuatro caracteres de variable_str.    

# Ejemplo:

digitos = 21212221251245
print(enmascarar(digitos))

# Output: ############1245