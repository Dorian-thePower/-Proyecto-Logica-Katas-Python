# 20. Para una lista con elementos tipo integer y string obtén una nueva lista sólo con los valores int. Usa la función filter()

def es_entero(elemento):
    return isinstance(elemento, int)

def lista_int(lista_mixta):
    return list(filter(es_entero, lista_mixta))

# Ejemplo:
lista_mixta = [11, "Hola", 33, "Nuevo"]
resultado = lista_int(lista_mixta)

print(resultado)
# Output: [11, 33]