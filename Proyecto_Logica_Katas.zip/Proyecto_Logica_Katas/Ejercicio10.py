# 10. Escribe una función que reciba una lista de números y calcule su promedio. 
# Si la lista está vacía, lanza una excepción personalizada y maneja el error adecuadamente

class Lista_Vacia(Exception):                                                     # Definimos una clase de excepción personalizada llamada Lista_Vacia que hereda de la clase base Exception. Esta clase se utilizará para indicar que la lista está vacía cuando se intente calcular el promedio.
    pass                                                                          # Ponemos pass para indicar que se implementa ninguna función adicional en esta clase de excepción personalizada.

def calcular_promedio(numeros):                                                    # Definimos una función llamada calcular_promedio que recibe una lista de números como argumento.
    if not numeros:                                                                    # Verificamos si la lista de números está vacía utilizando la condición if not numeros. Si la lista está vacía, se lanza una excepción personalizada Lista_Vacia con un mensaje que indica que no se puede calcular el promedio.
        raise Lista_Vacia("La lista está vacía, no se puede calcular el promedio.")
    return sum(numeros) / len(numeros)                                                 # Si la lista no está vacía, se calcula el promedio sumando todos los números en la lista utilizando la función sum() y dividiendo por la cantidad de números en la lista utilizando len(). El resultado se devuelve como el promedio de los números en la lista.

# Ejemplo:  

try:                                                                            # Utilizamos try para intentar calcular el promedio de una lista de números. Si la lista está vacía, se lanzará la excepción personalizada Lista_Vacia y se manejará en el bloque except.
    lista = [10, 58, 47, 8]
    promedio = calcular_promedio(lista)
    print("El promedio es:", round(promedio, 2))
except Lista_Vacia:
    print("La lista está vacía, no se puede calcular el promedio.")

  # Output: 30.75 
  # Output Lista Vacia: La lista está vacía, no se puede calcular el promedio.