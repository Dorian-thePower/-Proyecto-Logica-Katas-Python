# 27. Crea una función que calcule el promedio de una lista de números.

def promedio(lista):
    return sum(lista) / len(lista)

# Ejemplo:

lista_numeros = [1, 3, 4, 3, 6, 33]
print (round(promedio(lista_numeros), 2))

# Output: 8.33