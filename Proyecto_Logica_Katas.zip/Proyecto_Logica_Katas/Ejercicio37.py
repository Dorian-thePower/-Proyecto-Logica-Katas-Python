# 37. Crea una función llamada procesar_texto que procesa un texto según la opción especificada: reemplazar_palabras , 
# procesar_texto .contar_palabras , eliminar_palabra . 
# Estas opciones son otras funciones que tenemos que definir primero y llamar dentro de la función 
# Código a seguir:

# 1. Crear una función contar_palabras para contar el número de veces que aparece cada palabra en el texto. Tiene que devolver un diccionario.
# 2. Crear una función reemplazar_palabras para remplazar una palabra_original del texto por una palabra_nueva . Tieneque devolver el texto con el remplazo de palabras.
# 3. Crear una función eliminar_palabra para eliminar una palabra del texto. Tiene que devolver el texto con la palabra eliminada.
# 4. Crear la función procesar_texto que tome un texto, una opción(entre "contar", "reemplazar", "eliminar") y un número de argumentos variable según la opción indicada.

# Caso de uso:
# Comprueba el funcionamiento completo de la función procesar_texto. 

def contar_palabras(texto):                                             # 1. Creamos la función contar_palabras para contar el número de veces que aparece cada palabra en el texto para devolver un diccionario. 
    palabras = texto.split()                                            # Se divide el texto en palabras utilizando el método split(), lo que genera una lista de palabras.
    conteo = {}                                                         # Se crea un diccionario vacío llamado conteo para almacenar el número de veces que aparece cada palabra.
    for palabra in palabras:                                            # Se recorre cada palabra en la lista de palabras.
        if palabra in conteo:                                           # Si la palabra ya está en el diccionario conteo, se incrementa su contador en 1.
            conteo[palabra] += 1
        else:                                                           # Si la palabra no está en el diccionario conteo, se agrega al diccionario con un contador inicial de 1.
            conteo[palabra] = 1
    return conteo                                                       # Se devuelve el diccionario conteo con el número de veces que aparece cada palabra en el texto.

def reemplazar_palabras(texto, palabra_original, palabra_nueva):        # 2. Creamos la función reemplazar_palabras para remplazar una palabra_original del texto por una palabra_nueva para devolver el texto con el remplazo de palabras. 
    return texto.replace(palabra_original, palabra_nueva)               # Con el método replace() se reemplazan todas las apariciones de palabra_original por palabra_nueva en el texto, y se devuelve el texto modificado.

def eliminar_palabra(texto, palabra_a_eliminar):                        # 3. Creamos la función eliminar_palabra para eliminar una palabra del texto y para devolver el texto con la palabra eliminada.
    return texto.replace(palabra_a_eliminar, "")                        # Con el método replace() se reemplazan todas las apariciones de palabra_a_eliminar por una cadena vacía "", lo que elimina la palabra del texto, y se devuelve el texto modificado.

def procesar_texto(texto, opcion, *args):                               # 4. Creamos la función procesar_texto que tome un texto, una opción(entre "contar", "reemplazar", "eliminar") y un número de argumentos variable según la opción indicada.
    if opcion == "contar":
        return contar_palabras(texto)
    elif opcion == "reemplazar":
        if len(args) != 2:
            raise ValueError("Para la opción 'reemplazar' se necesitan dos argumentos: palabra_original y palabra_nueva")
        return reemplazar_palabras(texto, args[0], args[1])            # Si la opción es "reemplazar", se verifica que se hayan proporcionado exactamente dos argumentos (palabra_original y palabra_nueva). 
    elif opcion == "eliminar":
        if len(args) != 1:
            raise ValueError("Para la opción 'eliminar' se necesita un argumento: palabra_a_eliminar")
        return eliminar_palabra(texto, args[0])
    else:
        raise ValueError("Opción no válida. Las opciones válidas son: 'contar', 'reemplazar', 'eliminar'")
    
# Ejemplo de caso de uso:

texto = "Hola mundo, hola a todos. El mundo es grande."                   # 1. Definimos una variable texto con una cadena de texto para probar la función procesar_texto con las diferentes opciones.
print(procesar_texto(texto, "contar"))                                    # 2. Contamos el número de veces que aparece cada palabra en el texto y mostramos el resultado por terminal.
print(procesar_texto(texto, "reemplazar", "mundo", "universo"))           # 3. Reemplazamos la palabra "mundo" por "universo" en el texto y mostramos el resultado por terminal.
print(procesar_texto(texto, "eliminar", "hola"))                          # 4. Eliminamos la palabra "hola" del texto y mostramos el resultado por terminal.

# Output:
# {'Hola': 1, 'mundo,': 1, 'hola': 1, 'a': 1, 'todos.': 1, 'El': 1, 'mundo': 1, 'es': 1, 'grande.': 1}
# Hola universo, hola a todos. El universo es grande.
# Hola mundo,  a todos. El mundo es grande.
