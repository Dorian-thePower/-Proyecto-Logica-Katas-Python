# 1. Escribe una función que reciba una cadena de texto como parámetro y devuelva un diccionario con las frecuencias de cada letra en la cadena. Los espacios no deben ser considerados.

def frecuencias_letras(texto):
    texto = texto.replace(" ", "")
    frecuencias = {}                         # Creamos un diccionario vacio nombrado como frecuencias

    for letra in texto:                      # Se recorren todas las lentras en el texto.        
        if letra in frecuencias:             # Si la letra existe y se repite se agrega al contador de frecuencias.
            frecuencias[letra] += 1          
        else:                                # Si la letra aparece por primera vez y no se repite, se añade a 1
            frecuencias[letra] = 1           
            
    return frecuencias            

# Ejemplo:

texto = "Python is super"
print(frecuencias_letras(texto))

# Output: {'p': 2, 'y': 1, 't': 1, 'h': 1, 'o': 1, 'n': 1, 'i': 1, 's': 2, 'u': 1, 'e': 1, 'r': 1}
