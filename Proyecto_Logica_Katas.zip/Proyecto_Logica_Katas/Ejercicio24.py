# 24. Calcula la diferencia total en los valores de una lista. Usa la función reduce() .    

from functools import reduce

def diferencia(lista):
    return reduce(lambda a, b: a - b, lista)

# Ejemplo:

numeros = [10, 2, 3, 4, 1]
print(diferencia(numeros))

# Output: 0