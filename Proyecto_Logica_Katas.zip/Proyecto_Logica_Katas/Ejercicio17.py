# 17. Crea una función que tome una lista de dígitos y devuelva el número correspondiente. Por ejemplo, [5,7,2] corresponde al número quinientos setenta y dos (572). Usa la función reduce()

from functools import reduce

def combinar(acumulado, d):                           # se define la función combinar con parametros acumulado y d (digito)
    return acumulado * 10 + d                         # se retorna el acumulado que se multiplica por 10 y se le suma el d

def lista_a_numero(digitos):                          # se define una funnción que pase una lista de números con parametro digitos
    return reduce(combinar, digitos)                  # mediante reduce se combinan los digitos uno a uno con la prinera función

print(lista_a_numero([5, 7, 2]))

# Output: 572
