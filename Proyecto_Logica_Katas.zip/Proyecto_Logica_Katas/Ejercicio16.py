# 16. Escribe una función que tome una cadena de texto y un número entero n como parámetros y devuelva una lista de todas las palabras que sean más largas que n. Usa la función filter()

def palabra_mas_larga(texto, n):
    return list(filter(lambda palabra: len(palabra) > n, texto.split()))

def filtrar_palabras(lista, n):
    return list(filter(lambda palabra: len(palabra) > n, lista))

# Ejemplo:

lista = ("Mercedes", "Audi", "TOYOTA", "SEat")
print(filtrar_palabras(lista, 4))

# Output: ['Mercedes', 'TOYOTA']